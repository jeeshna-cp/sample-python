val1=int(input("enter 1st number:"))
val2=float(input("enter 2nd number:"))
sum=val1+val2
print(sum)

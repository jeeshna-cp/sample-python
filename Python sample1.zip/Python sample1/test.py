x=10
y="Arun"
print(x)
print(y)
#y is same as 
y='Akhil'
print(y)

x=3
print(x)

the_fruit="Apples"
print(the_fruit)

THEFRUIT="mango"
print(THEFRUIT)

thefruit3="banana"
print(thefruit3)

stud1,stud2,stud3="akhil","amal","amaya"
print(stud1)
print(stud2)
print(stud3)

print("hello world")
